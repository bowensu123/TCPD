import torch
import torch.nn as nn
import numpy as np

class Simple3DEncoder(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.out_channels = out_channels
        self.conv1 = nn.Conv3d(256, 256, kernel_size=3, padding=1)
        #self.conv2 = nn.Conv3d(64, out_channels, kernel_size=3, padding=1)
        
    def forward(self, x):
        x = self.conv1(x)
        #x = torch.relu(self.conv1(x))
        #x = self.conv2(x)
        return x

class Config:
    def __init__(self):
        self.use_quant_conv = False
        self.latent_channels = 32

class TiledEncoder3D(nn.Module):
    def __init__(self, encoder, config, tile_sample_min_size=32, tile_overlap_factor=0.10):
        super().__init__()
        self.encoder = encoder
        self.config = config
        self.tile_sample_min_size = tile_sample_min_size
        self.tile_overlap_factor = tile_overlap_factor
        self.tile_latent_min_size = tile_sample_min_size  # 假设编码器不改变空间尺寸
    
    def blend_d(self, prev_tile, curr_tile, blend_extent):
        """在深度方向混合两个tile"""
        blend_mask = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
        blend_mask = blend_mask.view(1, 1, blend_extent, 1, 1)
        
        prev_overlap = prev_tile[:, :, -blend_extent:, :, :]
        curr_overlap = curr_tile[:, :, :blend_extent, :, :]
        
        blended = prev_overlap * (1 - blend_mask) + curr_overlap * blend_mask
        
        result = curr_tile.clone()
        result[:, :, :blend_extent, :, :] = blended
        
        return result
    
    def blend_v(self, prev_tile, curr_tile, blend_extent):
        """在高度方向混合两个tile"""
        blend_mask = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
        blend_mask = blend_mask.view(1, 1, 1, blend_extent, 1)
        
        prev_overlap = prev_tile[:, :, :, -blend_extent:, :]
        curr_overlap = curr_tile[:, :, :, :blend_extent, :]
        
        blended = prev_overlap * (1 - blend_mask) + curr_overlap * blend_mask
        
        result = curr_tile.clone()
        result[:, :, :, :blend_extent, :] = blended
        
        return result
    
    def blend_h(self, prev_tile, curr_tile, blend_extent):
        """在宽度方向混合两个tile"""
        blend_mask = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
        blend_mask = blend_mask.view(1, 1, 1, 1, blend_extent)
        
        prev_overlap = prev_tile[:, :, :, :, -blend_extent:]
        curr_overlap = curr_tile[:, :, :, :, :blend_extent]
        
        blended = prev_overlap * (1 - blend_mask) + curr_overlap * blend_mask
        
        result = curr_tile.clone()
        result[:, :, :, :, :blend_extent] = blended
        
        return result
    
    def _tiled_encode(self, x: torch.Tensor) -> torch.Tensor:
        """Encode a 5D tensor using tiled encoding with depth-wise splitting."""
        overlap_size = int(self.tile_sample_min_size * (1 - self.tile_overlap_factor))
        blend_extent = int(self.tile_latent_min_size * self.tile_overlap_factor)
        row_limit = self.tile_latent_min_size - blend_extent

        batch_size, channels, depth, height, width = x.shape
        
        # 存储所有处理后的分块
        depth_slices = []
        
        # 按深度分块
        for d in range(0, depth, overlap_size):
            height_rows = []
            
            # 按高度分块
            for h in range(0, height, overlap_size):
                width_tiles = []
                
                # 按宽度分块
                for w in range(0, width, overlap_size):
                    # 提取3D tile
                    tile = x[
                        :, :,
                        d:min(d + self.tile_sample_min_size, depth),
                        h:min(h + self.tile_sample_min_size, height),
                        w:min(w + self.tile_sample_min_size, width)
                    ]
                    
                    # 处理tile
                    tile = self.encoder(tile)
                    if hasattr(self, 'quant_conv') and self.config.use_quant_conv:
                        tile = self.quant_conv(tile)
                    
                    width_tiles.append(tile)
                
                height_rows.append(width_tiles)
            
            depth_slices.append(height_rows)
        
        # 重建输出 - 严格遵循原始代码的拼接逻辑
        result_depth = []
        for d, depth_slice in enumerate(depth_slices):
            result_height = []
            for h, height_slice in enumerate(depth_slice):
                result_width = []
                for w, tile in enumerate(height_slice):
                    # 混合操作
                    if d > 0:
                        tile = self.blend_d(depth_slices[d-1][h][w], tile, blend_extent)
                    if h > 0:
                        tile = self.blend_v(depth_slice[h-1][w], tile, blend_extent)
                    if w > 0:
                        tile = self.blend_h(height_slice[w-1], tile, blend_extent)
                    
                    # 裁剪重叠区域
                    tile = tile[:, :, :row_limit, :row_limit, :row_limit]
                    result_width.append(tile)
                
                # 沿宽度维度拼接
                result_height.append(torch.cat(result_width, dim=4))
            
            # 沿高度维度拼接
            result_depth.append(torch.cat(result_height, dim=3))
        
        # 沿深度维度拼接
        enc = torch.cat(result_depth, dim=2)
        return enc
    
    def normal_encode(self, x):
        """正常编码（不分块）"""
        return self.encoder(x)
    
    def forward(self, x, use_tiled=True):
        if use_tiled:
            return self._tiled_encode(x)
        else:
            return self.normal_encode(x)

def compare_encodings():
    """比较分块编码和正常编码的输出差异"""
    # 设置随机种子以确保可重复性
    torch.manual_seed(42)
    
    # 创建编码器和配置
    encoder = Simple3DEncoder(3, 64)
    config = Config()
    
    tiled_encoder = TiledEncoder3D(encoder, config, tile_sample_min_size=32, tile_overlap_factor=0.25).cuda()
    

    x = torch.randn(1, 256, 96, 180, 480).cuda()
    
    # 设置为评估模式
    tiled_encoder.eval()
    
    print(f"输入形状: {x.shape}")
    
    # 正常编码
    with torch.no_grad():
        normal_output = tiled_encoder(x, use_tiled=False)
        print(f"正常输出形状: {normal_output.shape}")
    
    # 分块编码
    with torch.no_grad():
        tiled_output = tiled_encoder(x, use_tiled=True)
        print(f"分块输出形状: {tiled_output.shape}")
    
    # 检查形状是否匹配
    if normal_output.shape != tiled_output.shape:
        print("错误: 输出形状不匹配!")
        print(f"正常输出形状: {normal_output.shape}")
        print(f"分块输出形状: {tiled_output.shape}")
        
        # 尝试调整分块大小
        print("尝试调整分块大小...")
        tiled_encoder.tile_sample_min_size = 16
        with torch.no_grad():
            tiled_output = tiled_encoder(x, use_tiled=True)
            print(f"调整后分块输出形状: {tiled_output.shape}")
            
            if normal_output.shape != tiled_output.shape:
                return None
    
    # 计算差异
    #diff = torch.norm(normal_output - tiled_output)
    #print(f"输出差异范数: {diff.item()}")
    
    # 检查是否有NaN或Inf值
    has_nan = torch.isnan(tiled_output).any().item()
    has_inf = torch.isinf(tiled_output).any().item()
    print(f"分块输出包含NaN: {has_nan}")
    print(f"分块输出包含Inf: {has_inf}")
    
    return {
        'max_diff': (normal_output - tiled_output).abs().max().item(),
        'mean_diff': (normal_output - tiled_output).abs().mean().item(),
        'mse': (normal_output - tiled_output).pow(2).mean().item(),
        'has_nan': has_nan,
        'has_inf': has_inf
    }

if __name__ == "__main__":
    results = compare_encodings()
    
    if results is not None:
        # 判断误差是否可接受
        acceptable_max_diff = 1e-3
        acceptable_mean_diff = 1e-4
        
        if results['mse'] < acceptable_max_diff and results['mean_diff'] < acceptable_mean_diff:
            print("\n✓ 分块编码与正常编码的输出差异在可接受范围内")
        else:
            #print(f"\n✗ 分块编码与正常编码的输出差异较大")
            print(f"均方误差: {results['mse']:.6f} (可接受: <{acceptable_max_diff})")
            print(f"最大误差: {results['max_diff']:.6f} (可接受: <{acceptable_max_diff})")
            print(f"平均误差: {results['mean_diff']:.6f} (可接受: <{acceptable_mean_diff})")