import torch
import torch.nn as nn
import psutil
import gc
import numpy as np
from typing import Optional, Tuple, Dict, Generator, List
import time
import matplotlib.pyplot as plt
from scipy.ndimage import zoom

# 尝试导入skimage，如果不存在则安装
try:
    from skimage.metrics import structural_similarity as ssim
    from skimage.metrics import peak_signal_noise_ratio as psnr
except ImportError:
    print("正在安装scikit-image库...")
    import subprocess
    subprocess.check_call(["pip", "install", "scikit-image"])
    from skimage.metrics import structural_similarity as ssim
    from skimage.metrics import peak_signal_noise_ratio as psnr

class MemoryTracker:
    """显存和内存监控工具"""
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.gpu_memory_before = 0
        self.gpu_memory_after = 0
        self.gpu_memory_peak = 0
        self.ram_memory_before = 0
        self.ram_memory_after = 0
        
    def start_tracking(self):
        """开始监控显存和内存"""
        gc.collect()
        torch.cuda.empty_cache() if torch.cuda.is_available() else None
        
        if torch.cuda.is_available():
            self.gpu_memory_before = torch.cuda.memory_allocated() / 1024**3  # GB
            torch.cuda.reset_peak_memory_stats()
        
        process = psutil.Process()
        self.ram_memory_before = process.memory_info().rss / 1024**3  # GB
        
    def end_tracking(self):
        """结束监控并获取结果"""
        if torch.cuda.is_available():
            self.gpu_memory_after = torch.cuda.memory_allocated() / 1024**3  # GB
            self.gpu_memory_peak = torch.cuda.max_memory_allocated() / 1024**3  # GB
        
        process = psutil.Process()
        self.ram_memory_after = process.memory_info().rss / 1024**3  # GB
        
    def get_current_gpu_memory(self):
        """获取当前GPU显存使用"""
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated() / 1024**3
        return 0.0
        
    def get_report(self) -> Dict:
        """获取内存使用报告"""
        return {
            'gpu_memory_before': self.gpu_memory_before,
            'gpu_memory_after': self.gpu_memory_after,
            'gpu_memory_peak': self.gpu_memory_peak,
            'gpu_memory_used': self.gpu_memory_after - self.gpu_memory_before,
            'gpu_memory_peak_delta': self.gpu_memory_peak - self.gpu_memory_before,
            'ram_memory_before': self.ram_memory_before,
            'ram_memory_after': self.ram_memory_after,
            'ram_memory_used': self.ram_memory_after - self.ram_memory_before
        }

class Simple3DEncoder(nn.Module):
    """简单的3D编码器模型"""
    def __init__(self, in_channels=3, out_channels=64):
        super().__init__()
        self.conv1 = nn.Conv3d(in_channels, 32, 3, padding=1)
        #self.conv2 = nn.Conv3d(32, 64, 3, padding=1)
        #self.conv3 = nn.Conv3d(64, out_channels, 3, padding=1)
        
    def forward(self, x):
        x = self.conv1(x)
        #x = torch.relu(self.conv1(x))
        #x = torch.relu(self.conv2(x))
        #x = self.conv3(x)
        return x

class NormalEncoder3D(nn.Module):
    """正常的3D编码器 - 未经处理的版本"""
    def __init__(self, encoder):
        super().__init__()
        self.encoder = encoder
        self.memory_tracker = MemoryTracker()
    
    def forward(self, x):
        """正常的前向传播"""
        self.memory_tracker.start_tracking()
        
        result = self.encoder(x)
            
        self.memory_tracker.end_tracking()
        return result

class KVCache:
    """KV Cache实现，用于缓存中间计算结果"""
    def __init__(self, max_size=10, cache_dtype=torch.float16):
        self.cache = {}
        self.max_size = max_size
        self.cache_order = []
        self.cache_dtype = cache_dtype
    
    def add(self, key, value):
        """添加键值对到缓存"""
        # 转换为指定数据类型以减少内存使用
        value = value.to(self.cache_dtype)
        
        if key in self.cache:
            # 更新现有键的值
            self.cache[key] = value
            # 将键移动到最近使用的位置
            self.cache_order.remove(key)
            self.cache_order.append(key)
        else:
            # 添加新键值对
            self.cache[key] = value
            self.cache_order.append(key)
            
            # 如果缓存已满，移除最久未使用的项
            if len(self.cache) > self.max_size:
                oldest_key = self.cache_order.pop(0)
                del self.cache[oldest_key]
    
    def get(self, key):
        """从缓存中获取值"""
        if key in self.cache:
            # 将键移动到最近使用的位置
            self.cache_order.remove(key)
            self.cache_order.append(key)
            # 返回转换为原始数据类型的结果
            return self.cache[key].to(torch.float32)
        return None
    
    def clear(self):
        """清空缓存"""
        self.cache.clear()
        self.cache_order.clear()

class StreamingEncoder3DWithKVCache(nn.Module):
    """使用KV Cache技术的流式3D编码器"""
    def __init__(self, encoder, tile_size=64, max_tiles_in_memory=1, cache_size=10):
        super().__init__()
        self.encoder = encoder
        self.tile_size = tile_size
        self.max_tiles_in_memory = max_tiles_in_memory
        self.memory_tracker = MemoryTracker()
        
        # 创建KV Cache
        self.kv_cache = KVCache(max_size=cache_size)
        
        # 预计算卷积核的键值对，避免重复计算
        self._precompute_kernels()
    
    def _precompute_kernels(self):
        """预计算卷积核的键值对"""
        # 这里可以预计算一些固定的卷积核或权重
        # 例如，可以预计算混合操作的权重矩阵
        pass
    
    def create_tile_generator(self, x: torch.Tensor, overlap_size: int) -> Generator:
        """创建tile生成器"""
        batch_size, channels, depth, height, width = x.shape
        
        for d in range(0, depth, overlap_size):
            for h in range(0, height, overlap_size):
                for w in range(0, width, overlap_size):
                    d_end = min(d + self.tile_size, depth)
                    h_end = min(h + self.tile_size, height)
                    w_end = min(w + self.tile_size, width)
                    
                    yield (
                        (d, h, w),
                        (d_end, h_end, w_end),
                        x[:, :, d:d_end, h:h_end, w:w_end].clone()
                    )
    
    def process_single_tile(self, tile: torch.Tensor, pos: Tuple[int, int, int]) -> torch.Tensor:
        """处理单个tile，使用KV Cache避免重复计算"""
        # 检查缓存中是否已有结果
        cache_key = f"tile_{pos[0]}_{pos[1]}_{pos[2]}"
        cached_result = self.kv_cache.get(cache_key)
        
        if cached_result is not None:
            return cached_result
        
        # 如果缓存中没有，则进行计算
        with torch.cuda.device(tile.device), torch.no_grad():
            encoded = self.encoder(tile)
            
            # 将结果添加到缓存
            self.kv_cache.add(cache_key, encoded)
            
            del tile
            torch.cuda.empty_cache()
            
            return encoded
    
    def blend_tiles(self, curr_tile: torch.Tensor, 
                   pos: Tuple[int, int, int],
                   blend_extent: int) -> torch.Tensor:
        """混合tile，使用KV Cache获取相邻tile"""
        d, h, w = pos
        
        # 深度混合 - 从缓存中获取前一个tile
        if d > 0:
            prev_pos = (d-1, h, w)
            prev_tile = self.kv_cache.get(f"tile_{prev_pos[0]}_{prev_pos[1]}_{prev_pos[2]}")
            if prev_tile is not None and blend_extent < curr_tile.shape[2] and blend_extent > 0:
                prev_region = prev_tile[:, :, -blend_extent:, :, :]
                curr_region = curr_tile[:, :, :blend_extent, :, :]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, -1, 1, 1)
                curr_tile[:, :, :blend_extent, :, :] = prev_region * (1 - weights) + curr_region * weights
        
        # 高度混合 - 从缓存中获取上一个tile
        if h > 0:
            prev_pos = (d, h-1, w)
            prev_tile = self.kv_cache.get(f"tile_{prev_pos[0]}_{prev_pos[1]}_{prev_pos[2]}")
            if prev_tile is not None and blend_extent < curr_tile.shape[3] and blend_extent > 0:
                prev_region = prev_tile[:, :, :, -blend_extent:, :]
                curr_region = curr_tile[:, :, :, :blend_extent, :]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, 1, -1, 1)
                curr_tile[:, :, :, :blend_extent, :] = prev_region * (1 - weights) + curr_region * weights
        
        # 宽度混合 - 从缓存中获取左边tile
        if w > 0:
            prev_pos = (d, h, w-1)
            prev_tile = self.kv_cache.get(f"tile_{prev_pos[0]}_{prev_pos[1]}_{prev_pos[2]}")
            if prev_tile is not None and blend_extent < curr_tile.shape[4] and blend_extent > 0:
                prev_region = prev_tile[:, :, :, :, -blend_extent:]
                curr_region = curr_tile[:, :, :, :, :blend_extent]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, 1, 1, -1)
                curr_tile[:, :, :, :, :blend_extent] = prev_region * (1 - weights) + curr_region * weights
        
        return curr_tile
    
    def forward(self, x: torch.Tensor, 
                overlap_size: int,
                blend_extent: int = 8,
                verbose: bool = False) -> torch.Tensor:
        """流式处理 - 使用KV Cache优化"""
        self.memory_tracker.start_tracking()
        initial_memory = self.memory_tracker.get_current_gpu_memory()
        
        batch_size, channels, depth, height, width = x.shape
        
        if verbose:
            print(f"🌊 流式处理开始 (使用KV Cache):")
            print(f"   输入: {x.shape}")
            print(f"   tile_size: {self.tile_size}")  
            print(f"   overlap_size: {overlap_size}")
            print(f"   blend_extent: {blend_extent}")
            print(f"   初始显存: {initial_memory:.2f}GB")
            print(f"   KV Cache大小: {self.kv_cache.max_size}")
        
        # 获取输出尺寸
        tile_generator = self.create_tile_generator(x, overlap_size)
        first_pos, first_end, first_tile = next(tile_generator)
        test_output = self.process_single_tile(first_tile.clone(), first_pos)
        out_channels = test_output.shape[1]
        out_shape = test_output.shape[2:]
        del test_output, first_tile
        torch.cuda.empty_cache()
        
        # 预分配输出空间
        output = torch.zeros((batch_size, out_channels, *out_shape), 
                           device='cpu', dtype=x.dtype)
        
        # 重新创建生成器
        tile_generator = self.create_tile_generator(x, overlap_size)
        
        tile_count = 0
        peak_memory = initial_memory
        
        # 处理每个tile
        for pos, end, tile_data in tile_generator:
            d, h, w = pos
            
            # 处理tile（使用KV Cache）
            processed_tile = self.process_single_tile(tile_data, pos)
            
            # 混合tile（使用KV Cache获取相邻tile）
            blended_tile = self.blend_tiles(processed_tile, pos, blend_extent)
            
            # 计算输出位置
            out_d_start = (d // overlap_size) * overlap_size
            out_h_start = (h // overlap_size) * overlap_size  
            out_w_start = (w // overlap_size) * overlap_size
            
            # 裁剪tile
            actual_d = min(overlap_size, blended_tile.shape[2])
            actual_h = min(overlap_size, blended_tile.shape[3])
            actual_w = min(overlap_size, blended_tile.shape[4])
            
            # 移动到CPU并写入输出
            cropped = blended_tile[:, :, :actual_d, :actual_h, :actual_w].cpu()
            
            # 确保不超出输出范围
            d_end = min(out_d_start + actual_d, out_shape[0])
            h_end = min(out_h_start + actual_h, out_shape[1])
            w_end = min(out_w_start + actual_w, out_shape[2])
            
            actual_d = d_end - out_d_start
            actual_h = h_end - out_h_start
            actual_w = w_end - out_w_start
            
            if actual_d > 0 and actual_h > 0 and actual_w > 0:
                output[:, :, 
                       out_d_start:out_d_start+actual_d,
                       out_h_start:out_h_start+actual_h, 
                       out_w_start:out_w_start+actual_w] = cropped[:, :, :actual_d, :actual_h, :actual_w]
            
            # 释放内存
            del processed_tile, blended_tile, cropped
            torch.cuda.empty_cache()
            
            tile_count += 1
            current_memory = self.memory_tracker.get_current_gpu_memory()
            peak_memory = max(peak_memory, current_memory)
            
            if verbose and tile_count % 10 == 0:
                print(f"   处理进度: {tile_count} tiles, 当前显存: {current_memory:.2f}GB")
                print(f"   KV Cache使用: {len(self.kv_cache.cache)}/{self.kv_cache.max_size}")
        
        # 清理
        self.kv_cache.clear()
        torch.cuda.empty_cache()
        
        self.memory_tracker.end_tracking()
        
        if verbose:
            print(f"   完成! 总计: {tile_count} tiles")
            print(f"   峰值显存: {peak_memory:.2f}GB")
            print(f"   显存增量: {peak_memory - initial_memory:.2f}GB")
        
        return output.to(x.device)

def calculate_metrics(output1, output2):
    """计算两个输出之间的误差指标"""
    # 确保两个输出具有相同的尺寸
    min_d = min(output1.shape[2], output2.shape[2])
    min_h = min(output1.shape[3], output2.shape[3])
    min_w = min(output1.shape[4], output2.shape[4])
    
    output1_cropped = output1[:, :, :min_d, :min_h, :min_w]
    output2_cropped = output2[:, :, :min_d, :min_h, :min_w]
    
    # 转换为numpy数组用于计算指标
    output1_np = output1_cropped.cpu().detach().numpy()
    output2_np = output2_cropped.cpu().detach().numpy()
    
    # 计算基本误差指标
    mae = np.mean(np.abs(output1_np - output2_np))
    mse = np.mean((output1_np - output2_np) ** 2)
    rmse = np.sqrt(mse)
    
    # 计算PSNR
    data_range = np.max(output1_np) - np.min(output1_np)
    if data_range == 0:  # 避免除以零
        data_range = 1.0
    psnr_value = psnr(output1_np, output2_np, data_range=data_range)
    
    # 计算SSIM（对每个切片计算然后取平均）
    ssim_values = []
    for d in range(min_d):
        for c in range(output1_np.shape[1]):
            slice1 = output1_np[0, c, d, :, :]
            slice2 = output2_np[0, c, d, :, :]
            if slice1.shape[0] > 0 and slice1.shape[1] > 0:  # 确保切片有有效尺寸
                ssim_val = ssim(slice1, slice2, data_range=data_range)
                ssim_values.append(ssim_val)
    
    ssim_mean = np.mean(ssim_values) if ssim_values else 0
    
    return {
        'mae': mae,
        'mse': mse,
        'rmse': rmse,
        'psnr': psnr_value,
        'ssim': ssim_mean,
        'output_shape1': output1.shape,
        'output_shape2': output2.shape,
        'cropped_shape': output1_cropped.shape
    }

def compare_encoders(input_shape, tile_size=64, overlap_size=32, blend_extent=8, num_tests=3, use_kv_cache=True):
    """对比正常编码器和流式编码器"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 创建测试数据
    batch_size, channels, depth, height, width = input_shape
    x = torch.randn(batch_size, channels, depth, height, width).to(device)
    print(f"输入形状: {x.shape}, 大小: {x.numel() * 4 / 1024**2:.1f}MB")
    
    # 创建编码器
    encoder = Simple3DEncoder(in_channels=channels, out_channels=64).to(device)
    normal_encoder = NormalEncoder3D(encoder)
    
    if use_kv_cache:
        streaming_encoder = StreamingEncoder3DWithKVCache(encoder, tile_size=tile_size, cache_size=10)
        print("使用KV Cache优化版本")
    else:
        # 使用普通流式编码器
        class SimpleStreamingEncoder3D(nn.Module):
            def __init__(self, encoder, tile_size=64):
                super().__init__()
                self.encoder = encoder
                self.tile_size = tile_size
                self.memory_tracker = MemoryTracker()
            
            def forward(self, x, overlap_size, blend_extent=8, verbose=False):
                # 简化的流式处理实现
                self.memory_tracker.start_tracking()
                result = self.encoder(x)
                self.memory_tracker.end_tracking()
                return result
        
        streaming_encoder = SimpleStreamingEncoder3D(encoder, tile_size=tile_size)
        print("使用普通流式编码器")
    
    results = {
        'normal': {'times': [], 'memory_peak': [], 'memory_delta': []},
        'streaming': {'times': [], 'memory_peak': [], 'memory_delta': []},
        'error_metrics': []
    }
    
    # 多次测试取平均值
    for i in range(num_tests):
        print(f"\n🔬 测试 {i+1}/{num_tests}")
        
        # 正常处理
        print("📊 正常处理...")
        gc.collect()
        torch.cuda.empty_cache()
        
        start_time = time.time()
        normal_output = normal_encoder(x)
        normal_time = time.time() - start_time
        normal_memory = normal_encoder.memory_tracker.get_report()
        
        results['normal']['times'].append(normal_time)
        results['normal']['memory_peak'].append(normal_memory['gpu_memory_peak'])
        results['normal']['memory_delta'].append(normal_memory['gpu_memory_peak_delta'])
        
        print(f"   时间: {normal_time:.2f}s")
        print(f"   峰值显存: {normal_memory['gpu_memory_peak_delta']:.2f}GB")
        
        # 流式处理
        print("🌊 流式处理...")
        gc.collect()
        torch.cuda.empty_cache()
        
        start_time = time.time()
        if use_kv_cache:
            streaming_output = streaming_encoder(x, overlap_size, blend_extent, verbose=(i==0))
        else:
            streaming_output = streaming_encoder(x, overlap_size, blend_extent, verbose=(i==0))
        streaming_time = time.time() - start_time
        streaming_memory = streaming_encoder.memory_tracker.get_report()
        
        results['streaming']['times'].append(streaming_time)
        results['streaming']['memory_peak'].append(streaming_memory['gpu_memory_peak'])
        results['streaming']['memory_delta'].append(streaming_memory['gpu_memory_peak_delta'])
        
        print(f"   时间: {streaming_time:.2f}s")
        print(f"   峰值显存: {streaming_memory['gpu_memory_peak_delta']:.2f}GB")
        
        # 计算误差指标（只在最后一次测试中计算）
        """
        if i == num_tests - 1:
            print("📏 计算误差指标...")
            error_metrics = calculate_metrics(normal_output, streaming_output)
            results['error_metrics'] = error_metrics
            
            print(f"   输出形状 - 正常: {error_metrics['output_shape1']}")
            print(f"   输出形状 - 流式: {error_metrics['output_shape2']}")
            print(f"   裁剪后形状: {error_metrics['cropped_shape']}")
            print(f"   MAE: {error_metrics['mae']:.6f}")
            print(f"   MSE: {error_metrics['mse']:.6f}")
            print(f"   RMSE: {error_metrics['rmse']:.6f}")
            print(f"   PSNR: {error_metrics['psnr']:.2f} dB")
            print(f"   SSIM: {error_metrics['ssim']:.4f}")
        """

        del normal_output, streaming_output
        gc.collect()
        torch.cuda.empty_cache()
    
    # 计算平均值
    for key in ['normal', 'streaming']:
        results[key]['avg_time'] = np.mean(results[key]['times'])
        results[key]['avg_memory_peak'] = np.mean(results[key]['memory_peak'])
        results[key]['avg_memory_delta'] = np.mean(results[key]['memory_delta'])
    
    return results

def plot_comparison(results, input_shape, use_kv_cache=True):
    """绘制对比图表"""
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
    
    # 时间对比
    times = [results['normal']['avg_time'], results['streaming']['avg_time']]
    labels = ['正常处理', 'KV Cache流式处理' if use_kv_cache else '普通流式处理']
    colors = ['lightblue', 'lightcoral']
    
    ax1.bar(labels, times, color=colors)
    ax1.set_ylabel('时间 (秒)')
    ax1.set_title('处理时间对比')
    for i, v in enumerate(times):
        ax1.text(i, v + 0.1, f'{v:.2f}s', ha='center')
    
    # 显存对比
    memory = [results['normal']['avg_memory_delta'], results['streaming']['avg_memory_delta']]
    
    ax2.bar(labels, memory, color=colors)
    ax2.set_ylabel('峰值显存 (GB)')
    ax2.set_title('峰值显存对比')
    for i, v in enumerate(memory):
        ax2.text(i, v + 0.1, f'{v:.2f}GB', ha='center')
    
    # 误差指标对比
    if results['error_metrics']:
        error_metrics = results['error_metrics']
        metrics_names = ['MAE', 'MSE', 'RMSE']
        metrics_values = [error_metrics['mae'], error_metrics['mse'], error_metrics['rmse']]
        
        ax3.bar(metrics_names, metrics_values, color=['lightgreen', 'lightyellow', 'lightpink'])
        ax3.set_ylabel('误差值')
        ax3.set_title('误差指标对比')
        for i, v in enumerate(metrics_values):
            ax3.text(i, v + 0.1 * max(metrics_values), f'{v:.6f}', ha='center')
    
    # 质量指标对比
    if results['error_metrics']:
        quality_metrics = {
            'PSNR': error_metrics['psnr'],
            'SSIM': error_metrics['ssim']
        }
        
        ax4.bar(quality_metrics.keys(), quality_metrics.values(), color=['lightcyan', 'lightgray'])
        ax4.set_ylabel('质量值')
        ax4.set_title('质量指标对比')
        for i, (k, v) in enumerate(quality_metrics.items()):
            ax4.text(i, v + 0.1 * max(quality_metrics.values()), f'{v:.4f}', ha='center')
    
    plt.tight_layout()
    cache_type = "kv_cache" if use_kv_cache else "normal"
    plt.savefig(f'comparison_{cache_type}_{input_shape[2]}x{input_shape[3]}x{input_shape[4]}.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 打印详细结果
    print("\n" + "="*70)
    print("📊 性能对比结果")
    print("="*70)
    print(f"输入形状: {input_shape}")
    print(f"测试次数: {len(results['normal']['times'])}")
    
    print(f"\n正常处理:")
    print(f"  平均时间: {results['normal']['avg_time']:.2f}s")
    print(f"  平均峰值显存: {results['normal']['avg_memory_delta']:.2f}GB")
    
    print(f"\n流式处理:")
    print(f"  平均时间: {results['streaming']['avg_time']:.2f}s")
    print(f"  平均峰值显存: {results['streaming']['avg_memory_delta']:.2f}GB")
    
    print(f"\n对比:")
    time_ratio = results['streaming']['avg_time'] / results['normal']['avg_time']
    memory_ratio = results['streaming']['avg_memory_delta'] / results['normal']['avg_memory_delta']
    
    print(f"  时间比例: {time_ratio:.2f}x")
    print(f"  显存比例: {memory_ratio:.2f}x")
    
    if memory_ratio < 1.0:
        memory_saved = results['normal']['avg_memory_delta'] - results['streaming']['avg_memory_delta']
        print(f"  显存节省: {memory_saved:.2f}GB ({memory_ratio*100:.1f}%)")
    
    if time_ratio > 1.0:
        print(f"  时间增加: {results['streaming']['avg_time'] - results['normal']['avg_time']:.2f}s")
    else:
        print(f"  时间节省: {results['normal']['avg_time'] - results['streaming']['avg_time']:.2f}s")
    
    #TODO
    """
    if results['error_metrics']:
        print(f"\n📏 误差指标:")
        print(f"  平均绝对误差 (MAE): {results['error_metrics']['mae']:.6f}")
        print(f"  均方误差 (MSE): {results['error_metrics']['mse']:.6f}")
        print(f"  均方根误差 (RMSE): {results['error_metrics']['rmse']:.6f}")
        print(f"  峰值信噪比 (PSNR): {results['error_metrics']['psnr']:.2f} dB")
        print(f"  结构相似性指数 (SSIM): {results['error_metrics']['ssim']:.4f}")
    """
def main():
    """主函数"""
    # 测试单个尺寸
    input_shape = (1, 32, 96, 96, 96)  # 批次, 通道, 深度, 高度, 宽度
    
    print("🚀 开始性能对比测试")
    print("="*50)
    
    # 测试KV Cache版本
    print("\n测试KV Cache优化版本...")
    results_kv = compare_encoders(
        input_shape=input_shape,
        tile_size=64,
        overlap_size=32,
        blend_extent=8,
        num_tests=3,
        use_kv_cache=True
    )
    
    plot_comparison(results_kv, input_shape, use_kv_cache=True)
    
    # 测试普通流式版本
    """
    print("\n测试普通流式处理版本...")
    results_normal = compare_encoders(
        input_shape=input_shape,
        tile_size=64,
        overlap_size=32,
        blend_extent=8,
        num_tests=3,
        use_kv_cache=False
    )
    
    plot_comparison(results_normal, input_shape, use_kv_cache=False)
    
    # 对比两个版本的性能
    print("\n" + "="*80)
    print("KV Cache vs 普通流式处理 性能对比")
    print("="*80)
    
    kv_memory_ratio = results_kv['streaming']['avg_memory_delta'] / results_kv['normal']['avg_memory_delta']
    normal_memory_ratio = results_normal['streaming']['avg_memory_delta'] / results_normal['normal']['avg_memory_delta']
    
    kv_time_ratio = results_kv['streaming']['avg_time'] / results_kv['normal']['avg_time']
    normal_time_ratio = results_normal['streaming']['avg_time'] / results_normal['normal']['avg_time']
    
    print(f"KV Cache版本 - 显存比例: {kv_memory_ratio:.2f}x, 时间比例: {kv_time_ratio:.2f}x")
    print(f"普通版本 - 显存比例: {normal_memory_ratio:.2f}x, 时间比例: {normal_time_ratio:.2f}x")
    
    memory_improvement = (normal_memory_ratio - kv_memory_ratio) / normal_memory_ratio * 100
    time_improvement = (normal_time_ratio - kv_time_ratio) / normal_time_ratio * 100
    
    print(f"显存优化: {memory_improvement:.1f}%")
    print(f"时间优化: {time_improvement:.1f}%")
    """

# 主程序入口
if __name__ == "__main__":
    main()