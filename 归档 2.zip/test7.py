import torch
import torch.nn as nn
import psutil
import gc
import numpy as np
from typing import Optional, Tuple, Dict, Generator
import time
import matplotlib.pyplot as plt

class MemoryTracker:
    """显存和内存监控工具"""
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.gpu_memory_before = 0
        self.gpu_memory_after = 0
        self.gpu_memory_peak = 0
        self.ram_memory_before = 0
        self.ram_memory_after = 0
        
    def start_tracking(self):
        """开始监控显存和内存"""
        gc.collect()
        torch.cuda.empty_cache() if torch.cuda.is_available() else None
        
        if torch.cuda.is_available():
            self.gpu_memory_before = torch.cuda.memory_allocated() / 1024**3  # GB
            torch.cuda.reset_peak_memory_stats()
        
        process = psutil.Process()
        self.ram_memory_before = process.memory_info().rss / 1024**3  # GB
        
    def end_tracking(self):
        """结束监控并获取结果"""
        if torch.cuda.is_available():
            self.gpu_memory_after = torch.cuda.memory_allocated() / 1024**3  # GB
            self.gpu_memory_peak = torch.cuda.max_memory_allocated() / 1024**3  # GB
        
        process = psutil.Process()
        self.ram_memory_after = process.memory_info().rss / 1024**3  # GB
        
    def get_current_gpu_memory(self):
        """获取当前GPU显存使用"""
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated() / 1024**3
        return 0.0
        
    def get_report(self) -> Dict:
        """获取内存使用报告"""
        return {
            'gpu_memory_before': self.gpu_memory_before,
            'gpu_memory_after': self.gpu_memory_after,
            'gpu_memory_peak': self.gpu_memory_peak,
            'gpu_memory_used': self.gpu_memory_after - self.gpu_memory_before,
            'gpu_memory_peak_delta': self.gpu_memory_peak - self.gpu_memory_before,
            'ram_memory_before': self.ram_memory_before,
            'ram_memory_after': self.ram_memory_after,
            'ram_memory_used': self.ram_memory_after - self.ram_memory_before
        }

class Simple3DEncoder(nn.Module):
    """简单的3D编码器模型"""
    def __init__(self, in_channels=3, out_channels=64):
        super().__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, padding=1)
        #self.conv2 = nn.Conv3d(32, 64, 3, padding=1)
        #self.conv3 = nn.Conv3d(64, out_channels, 3, padding=1)
        
    def forward(self, x):
        x = self.conv1(x)
        #x = torch.relu(self.conv1(x))
        #x = torch.relu(self.conv2(x))
        #x = self.conv3(x)
        return x

class NormalEncoder3D(nn.Module):
    """正常的3D编码器 - 未经处理的版本"""
    def __init__(self, encoder):
        super().__init__()
        self.encoder = encoder
        self.memory_tracker = MemoryTracker()
    
    def forward(self, x):
        """正常的前向传播"""
        self.memory_tracker.start_tracking()
        
        result = self.encoder(x)
            
        self.memory_tracker.end_tracking()
        return result

class StreamingEncoder3D(nn.Module):
    """流式3D编码器 - 优化版本"""
    def __init__(self, encoder, tile_size=64, max_tiles_in_memory=1):
        super().__init__()
        self.encoder = encoder
        self.tile_size = tile_size
        self.max_tiles_in_memory = max_tiles_in_memory
        self.memory_tracker = MemoryTracker()
    
    def create_tile_generator(self, x: torch.Tensor, overlap_size: int) -> Generator:
        """创建tile生成器"""
        batch_size, channels, depth, height, width = x.shape
        
        for d in range(0, depth, overlap_size):
            for h in range(0, height, overlap_size):
                for w in range(0, width, overlap_size):
                    d_end = min(d + self.tile_size, depth)
                    h_end = min(h + self.tile_size, height)
                    w_end = min(w + self.tile_size, width)
                    
                    yield (
                        (d, h, w),
                        (d_end, h_end, w_end),
                        x[:, :, d:d_end, h:h_end, w:w_end].clone()
                    )
    
    def process_single_tile(self, tile: torch.Tensor) -> torch.Tensor:
        """处理单个tile"""
        with torch.cuda.device(tile.device), torch.no_grad():
            encoded = self.encoder(tile)
            del tile
            torch.cuda.empty_cache()
            return encoded
    
    def blend_tiles(self, curr_tile: torch.Tensor, 
                   prev_tiles: Dict, 
                   pos: Tuple[int, int, int],
                   blend_extent: int) -> torch.Tensor:
        """混合tile"""
        d, h, w = pos
        
        # 深度混合
        if (d-1, h, w) in prev_tiles:
            prev_tile = prev_tiles[(d-1, h, w)]
            if blend_extent < curr_tile.shape[2] and blend_extent > 0:
                prev_region = prev_tile[:, :, -blend_extent:, :, :]
                curr_region = curr_tile[:, :, :blend_extent, :, :]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, -1, 1, 1)
                curr_tile[:, :, :blend_extent, :, :] = prev_region * (1 - weights) + curr_region * weights
        
        # 高度混合
        if (d, h-1, w) in prev_tiles:
            prev_tile = prev_tiles[(d, h-1, w)]
            if blend_extent < curr_tile.shape[3] and blend_extent > 0:
                prev_region = prev_tile[:, :, :, -blend_extent:, :]
                curr_region = curr_tile[:, :, :, :blend_extent, :]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, 1, -1, 1)
                curr_tile[:, :, :, :blend_extent, :] = prev_region * (1 - weights) + curr_region * weights
        
        # 宽度混合
        if (d, h, w-1) in prev_tiles:
            prev_tile = prev_tiles[(d, h, w-1)]
            if blend_extent < curr_tile.shape[4] and blend_extent > 0:
                prev_region = prev_tile[:, :, :, :, -blend_extent:]
                curr_region = curr_tile[:, :, :, :, :blend_extent]
                weights = torch.linspace(0, 1, blend_extent, device=curr_tile.device)
                weights = weights.view(1, 1, 1, 1, -1)
                curr_tile[:, :, :, :, :blend_extent] = prev_region * (1 - weights) + curr_region * weights
        
        return curr_tile
    
    def forward(self, x: torch.Tensor, 
                overlap_size: int,
                blend_extent: int = 8,
                verbose: bool = False) -> torch.Tensor:
        """流式处理"""
        self.memory_tracker.start_tracking()
        initial_memory = self.memory_tracker.get_current_gpu_memory()
        
        batch_size, channels, depth, height, width = x.shape
        
        if verbose:
            print(f"🌊 流式处理开始:")
            print(f"   输入: {x.shape}")
            print(f"   tile_size: {self.tile_size}")  
            print(f"   overlap_size: {overlap_size}")
            print(f"   blend_extent: {blend_extent}")
            print(f"   初始显存: {initial_memory:.2f}GB")
        
        # 获取输出尺寸
        tile_generator = self.create_tile_generator(x, overlap_size)
        first_pos, first_end, first_tile = next(tile_generator)
        test_output = self.process_single_tile(first_tile.clone())
        out_channels = test_output.shape[1]
        out_shape = test_output.shape[2:]
        del test_output, first_tile
        torch.cuda.empty_cache()
        
        # 预分配输出空间
        output = torch.zeros((batch_size, out_channels, *out_shape), 
                           device='cpu', dtype=x.dtype)
        
        # 重新创建生成器
        tile_generator = self.create_tile_generator(x, overlap_size)
        
        # 缓存管理
        tile_cache = {}
        cache_order = []
        
        tile_count = 0
        peak_memory = initial_memory
        
        # 处理每个tile
        for pos, end, tile_data in tile_generator:
            d, h, w = pos
            
            # 处理tile
            processed_tile = self.process_single_tile(tile_data)
            
            # 混合tile
            blended_tile = self.blend_tiles(processed_tile, tile_cache, pos, blend_extent)
            
            # 计算输出位置
            out_d_start = (d // overlap_size) * overlap_size
            out_h_start = (h // overlap_size) * overlap_size  
            out_w_start = (w // overlap_size) * overlap_size
            
            # 裁剪tile
            actual_d = min(overlap_size, blended_tile.shape[2])
            actual_h = min(overlap_size, blended_tile.shape[3])
            actual_w = min(overlap_size, blended_tile.shape[4])
            
            # 移动到CPU并写入输出
            cropped = blended_tile[:, :, :actual_d, :actual_h, :actual_w].cpu()
            
            # 确保不超出输出范围
            d_end = min(out_d_start + actual_d, out_shape[0])
            h_end = min(out_h_start + actual_h, out_shape[1])
            w_end = min(out_w_start + actual_w, out_shape[2])
            
            actual_d = d_end - out_d_start
            actual_h = h_end - out_h_start
            actual_w = w_end - out_w_start
            
            if actual_d > 0 and actual_h > 0 and actual_w > 0:
                output[:, :, 
                       out_d_start:out_d_start+actual_d,
                       out_h_start:out_h_start+actual_h, 
                       out_w_start:out_w_start+actual_w] = cropped[:, :, :actual_d, :actual_h, :actual_w]
            
            # 更新缓存
            tile_cache[pos] = blended_tile
            cache_order.append(pos)
            
            # 限制缓存大小
            while len(tile_cache) > self.max_tiles_in_memory:
                oldest_pos = cache_order.pop(0)
                if oldest_pos in tile_cache:
                    del tile_cache[oldest_pos]
            
            # 释放内存
            del processed_tile, blended_tile, cropped
            torch.cuda.empty_cache()
            
            tile_count += 1
            current_memory = self.memory_tracker.get_current_gpu_memory()
            peak_memory = max(peak_memory, current_memory)
            
            if verbose and tile_count % 10 == 0:
                print(f"   处理进度: {tile_count} tiles, 当前显存: {current_memory:.2f}GB")
        
        # 清理
        del tile_cache, cache_order
        torch.cuda.empty_cache()
        
        self.memory_tracker.end_tracking()
        
        if verbose:
            print(f"   完成! 总计: {tile_count} tiles")
            print(f"   峰值显存: {peak_memory:.2f}GB")
            print(f"   显存增量: {peak_memory - initial_memory:.2f}GB")
        
        return output.to(x.device)

def compare_encoders(input_shape, tile_size=64, overlap_size=32, blend_extent=8, num_tests=3):
    """对比正常编码器和流式编码器"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 创建测试数据
    batch_size, channels, depth, height, width = input_shape
    x = torch.randn(batch_size, channels, depth, height, width).to(device)
    print(f"输入形状: {x.shape}, 大小: {x.numel() * 4 / 1024**2:.1f}MB")
    
    # 创建编码器
    encoder = Simple3DEncoder(in_channels=channels, out_channels=256).to(device)
    normal_encoder = NormalEncoder3D(encoder)
    streaming_encoder = StreamingEncoder3D(encoder, tile_size=tile_size)
    
    results = {
        'normal': {'times': [], 'memory_peak': [], 'memory_delta': []},
        'streaming': {'times': [], 'memory_peak': [], 'memory_delta': []}
    }
    
    # 多次测试取平均值
    for i in range(num_tests):
        print(f"\n Testing {i+1}/{num_tests}")
        
        # 正常处理
        print("Normal version...")
        gc.collect()
        torch.cuda.empty_cache()
        
        start_time = time.time()
        normal_output = normal_encoder(x)
        normal_time = time.time() - start_time
        normal_memory = normal_encoder.memory_tracker.get_report()
        
        results['normal']['times'].append(normal_time)
        results['normal']['memory_peak'].append(normal_memory['gpu_memory_peak'])
        results['normal']['memory_delta'].append(normal_memory['gpu_memory_peak_delta'])
        
        print(f"Time: {normal_time:.2f}s")
        print(f"Peak VRAM: {normal_memory['gpu_memory_peak_delta']:.2f}GB")
        
        # 清理
        del normal_output
        gc.collect()
        torch.cuda.empty_cache()
        
        # 流式处理
        print("Streaming...")
        gc.collect()
        torch.cuda.empty_cache()
        
        start_time = time.time()
        streaming_output = streaming_encoder(x, overlap_size, blend_extent, verbose=(i==0))
        streaming_time = time.time() - start_time
        streaming_memory = streaming_encoder.memory_tracker.get_report()
        
        results['streaming']['times'].append(streaming_time)
        results['streaming']['memory_peak'].append(streaming_memory['gpu_memory_peak'])
        results['streaming']['memory_delta'].append(streaming_memory['gpu_memory_peak_delta'])
        
        print(f"Time: {streaming_time:.2f}s")
        print(f"Peak VRAM: {streaming_memory['gpu_memory_peak_delta']:.2f}GB")
        
        # 清理
        del streaming_output
        gc.collect()
        torch.cuda.empty_cache()
    
    # 计算平均值
    for key in results:
        results[key]['avg_time'] = np.mean(results[key]['times'])
        results[key]['avg_memory_peak'] = np.mean(results[key]['memory_peak'])
        results[key]['avg_memory_delta'] = np.mean(results[key]['memory_delta'])
    
    return results

def plot_comparison(results, input_shape):
    """绘制对比图表"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # 时间对比
    times = [results['normal']['avg_time'], results['streaming']['avg_time']]
    labels = ['Normal', 'Streaming']
    colors = ['lightblue', 'lightcoral']
    
    ax1.bar(labels, times, color=colors)
    ax1.set_ylabel('Time (s)')
    ax1.set_title('Time Comparison')
    for i, v in enumerate(times):
        ax1.text(i, v + 0.1, f'{v:.2f}s', ha='center')
    
    # 显存对比
    memory = [results['normal']['avg_memory_delta'], results['streaming']['avg_memory_delta']]
    
    ax2.bar(labels, memory, color=colors)
    ax2.set_ylabel('VRAM(GB)')
    ax2.set_title('VRAM Comparison')
    for i, v in enumerate(memory):
        ax2.text(i, v + 0.1, f'{v:.2f}GB', ha='center')
    
    plt.tight_layout()
    plt.savefig(f'comparison_{input_shape[2]}x{input_shape[3]}x{input_shape[4]}.png')
    plt.show()
    
    # 打印详细结果
    print("\n" + "="*70)
    print("Comparison Results")
    print("="*70)
    print(f"Input size: {input_shape}")
    print(f"Test Time: {len(results['normal']['times'])}")
    
    print(f"\n正常处理:")
    print(f"Average Time: {results['normal']['avg_time']:.2f}s")
    print(f"Average Peak Memory: {results['normal']['avg_memory_delta']:.2f}GB")
    
    print(f"\nStream Processing:")
    print(f"Average Time: {results['streaming']['avg_time']:.2f}s")
    print(f"Average Peak Vram: {results['streaming']['avg_memory_delta']:.2f}GB")
    
    print(f"\nComparison:")
    time_ratio = results['streaming']['avg_time'] / results['normal']['avg_time']
    memory_ratio = results['streaming']['avg_memory_delta'] / results['normal']['avg_memory_delta']
    
    print(f"Time Ratio: {time_ratio:.2f}x")
    print(f"VRAM Ratio: {memory_ratio:.2f}x")
    
    if memory_ratio < 1.0:
        memory_saved = results['normal']['avg_memory_delta'] - results['streaming']['avg_memory_delta']
        print(f"memory saving: {memory_saved:.2f}GB ({memory_ratio*100:.1f}%)")
    
    if time_ratio > 1.0:
        print(f"Time adding: {results['streaming']['avg_time'] - results['normal']['avg_time']:.2f}s")
    else:
        print(f"Time saving: {results['normal']['avg_time'] - results['streaming']['avg_time']:.2f}s")

def test_different_sizes():
    """Different size"""
    sizes = [
        (1, 32, 64, 64, 64),   # small
        (1, 32, 96, 96, 96),   # midium
        (1, 32, 128, 128, 128) # large
    ]
    
    all_results = {}
    
    for size in sizes:
        print(f"\n{'='*80}")
        print(f"测试输入尺寸: {size}")
        print(f"{'='*80}")
        
        # 根据尺寸调整参数
        tile_size = min(64, size[2] // 2)
        overlap_size = max(16, tile_size // 2)
        
        results = compare_encoders(
            input_shape=size,
            tile_size=tile_size,
            overlap_size=overlap_size,
            blend_extent=8,
            num_tests=2  # 减少测试次数以节省时间
        )
        
        all_results[str(size)] = results
        plot_comparison(results, size)
    
    return all_results

# 主程序
if __name__ == "__main__":
    # 测试单个尺寸
    input_shape = (1, 32, 96, 96, 96)  # batch,channel,depth, height, width
    
    results = compare_encoders(
        input_shape=input_shape,
        tile_size=64,
        overlap_size=32,
        blend_extent=8,
        num_tests=3
    )
    
    #plot_comparison(results, input_shape)
    
    # 测试多个尺寸（可选）
    all_results = test_different_sizes()