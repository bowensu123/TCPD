import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import gc
from typing import List, Tuple, Dict
import matplotlib.pyplot as plt
import numpy as np

class NormalVAEEncoder3D(nn.Module):
    """传统的3D VAE编码器 - 一次性处理整个输入"""
    def __init__(self, in_channels, hidden_channels, z_dim):
        super(NormalVAEEncoder3D, self).__init__()
        self.z_dim = z_dim
        
        # 卷积层
        self.conv1 = nn.Conv3d(in_channels, hidden_channels, kernel_size=3, stride=2, padding=1)
        self.conv2 = nn.Conv3d(hidden_channels, hidden_channels * 2, kernel_size=3, stride=2, padding=1)
        self.conv3 = nn.Conv3d(hidden_channels * 2, hidden_channels * 4, kernel_size=3, stride=2, padding=1)
        
        # 批归一化
        self.bn1 = nn.BatchNorm3d(hidden_channels)
        self.bn2 = nn.BatchNorm3d(hidden_channels * 2)
        self.bn3 = nn.BatchNorm3d(hidden_channels * 4)
        
        self.dropout = nn.Dropout(0.2)
        
        # 全连接层 - 需要在第一次前向传播时初始化
        self.fc1 = None
        self.fc21 = None  # 均值
        self.fc22 = None  # log方差
    
    def _initialize_fc_layers(self, flatten_size):
        if self.fc1 is None:
            hidden_fc_size = min(1024, flatten_size // 4)  # 更大的隐藏层
            device = next(self.parameters()).device
            self.fc1 = nn.Linear(flatten_size, hidden_fc_size).to(device)
            self.fc21 = nn.Linear(hidden_fc_size, self.z_dim).to(device)
            self.fc22 = nn.Linear(hidden_fc_size, self.z_dim).to(device)
    
    def forward(self, x):
        # 卷积特征提取
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = self.dropout(x)
        
        # 展平
        batch_size = x.size(0)
        flatten_size = x.numel() // batch_size
        
        self._initialize_fc_layers(flatten_size)
        
        x = x.view(batch_size, -1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        
        z_mean = self.fc21(x)
        z_log_var = self.fc22(x)
        
        return [(z_mean, z_log_var)]  # 返回列表格式以匹配tile版本


class TileVAEEncoder3D(nn.Module):
    """Tile处理的3D VAE编码器"""
    def __init__(self, in_channels, hidden_channels, z_dim, tile_size):
        super(TileVAEEncoder3D, self).__init__()
        self.tile_size = tile_size
        self.z_dim = z_dim
        
        # 卷积层
        self.conv1 = nn.Conv3d(in_channels, hidden_channels, kernel_size=3, stride=2, padding=1)
        self.conv2 = nn.Conv3d(hidden_channels, hidden_channels * 2, kernel_size=3, stride=2, padding=1)
        self.conv3 = nn.Conv3d(hidden_channels * 2, hidden_channels * 4, kernel_size=3, stride=2, padding=1)
        
        # 批归一化
        self.bn1 = nn.BatchNorm3d(hidden_channels)
        self.bn2 = nn.BatchNorm3d(hidden_channels * 2)
        self.bn3 = nn.BatchNorm3d(hidden_channels * 4)
        
        self.dropout = nn.Dropout(0.2)
        
        # 动态初始化的全连接层
        self.fc1 = None
        self.fc21 = None  # 均值
        self.fc22 = None  # log方差
        
    def _initialize_fc_layers(self, flatten_size):
        if self.fc1 is None:
            hidden_fc_size = min(512, flatten_size // 2)
            device = next(self.parameters()).device
            self.fc1 = nn.Linear(flatten_size, hidden_fc_size).to(device)
            self.fc21 = nn.Linear(hidden_fc_size, self.z_dim).to(device)
            self.fc22 = nn.Linear(hidden_fc_size, self.z_dim).to(device)
    
    def _process_tile(self, tile):
        # 卷积特征提取
        x = F.relu(self.bn1(self.conv1(tile)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = self.dropout(x)
        
        # 展平
        batch_size = x.size(0)
        flatten_size = x.numel() // batch_size
        
        self._initialize_fc_layers(flatten_size)
        
        x = x.view(batch_size, -1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        
        z_mean = self.fc21(x)
        z_log_var = self.fc22(x)
        
        return z_mean, z_log_var
    
    def forward(self, x):
        batch_size, channels, depth, height, width = x.shape
        tiles_output = []
        
        for i in range(0, depth, self.tile_size):
            end_idx = min(i + self.tile_size, depth)
            tile = x[:, :, i:end_idx, :, :]
            
            if tile.size(2) < self.tile_size // 2:
                continue
                
            z_mean, z_log_var = self._process_tile(tile)
            tiles_output.append((z_mean, z_log_var))
        
        return tiles_output


class MemoryComparator:
    def __init__(self, device):
        self.device = device
        self.comparison_results = []
        
    def clear_cache(self):
        """清理显存缓存"""
        if self.device.type == 'cuda':
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            gc.collect()
    
    def get_memory_info(self):
        """获取当前显存使用信息"""
        if self.device.type == 'cuda':
            allocated = torch.cuda.memory_allocated() / (1024**3)  # GB
            reserved = torch.cuda.memory_reserved() / (1024**3)   # GB
            max_allocated = torch.cuda.max_memory_allocated() / (1024**3)  # GB
            return allocated, reserved, max_allocated
        return 0, 0, 0
    
    def profile_single_model(self, model, input_tensor, model_type):
        """分析单个模型的显存使用"""
        print(f"\n--- {model_type} 模型测试 ---")
        
        if self.device.type == 'cuda':
            torch.cuda.reset_peak_memory_stats()
        
        self.clear_cache()
        
        # 初始显存
        initial_allocated, initial_reserved, _ = self.get_memory_info()
        
        # 模型参数显存
        model_params = sum(p.numel() for p in model.parameters())
        model_memory = model_params * 4 / (1024**3)  # 假设float32
        
        # 输入数据显存
        input_memory = input_tensor.numel() * input_tensor.element_size() / (1024**3)
        
        print(f"模型参数: {model_params:,} ({model_memory:.3f} GB)")
        print(f"输入数据: {input_memory:.3f} GB")
        
        # 前向传播
        start_time = time.time()
        
        try:
            with torch.no_grad():
                output = model(input_tensor)
            
            if self.device.type == 'cuda':
                torch.cuda.synchronize()
            
            success = True
            error_msg = None
            
        except RuntimeError as e:
            success = False
            error_msg = str(e)
            print(f"❌ 模型执行失败: {error_msg}")
            output = []
        
        end_time = time.time()
        
        # 显存统计
        final_allocated, final_reserved, peak_allocated = self.get_memory_info()
        
        # 计算显存使用
        total_memory_used = final_allocated - initial_allocated
        peak_memory_used = peak_allocated - initial_allocated
        processing_time = end_time - start_time
        
        if success:
            num_outputs = len(output)
            total_latent_dims = sum(z_mean.numel() + z_log_var.numel() for z_mean, z_log_var in output)
            
            print(f"✅ 执行成功")
            print(f"输出数量: {num_outputs}")
            print(f"总潜在变量维度: {total_latent_dims}")
        else:
            num_outputs = 0
            total_latent_dims = 0
        
        print(f"峰值显存: {peak_memory_used:.3f} GB")
        print(f"最终显存: {total_memory_used:.3f} GB")
        print(f"处理时间: {processing_time:.3f} 秒")
        
        return {
            'model_type': model_type,
            'success': success,
            'error_msg': error_msg,
            'model_memory': model_memory,
            'input_memory': input_memory,
            'peak_memory': peak_memory_used,
            'final_memory': total_memory_used,
            'processing_time': processing_time,
            'num_outputs': num_outputs,
            'total_latent_dims': total_latent_dims,
            'model_params': model_params
        }
    
    def compare_models(self, input_tensor, hidden_channels=64, z_dim=32, tile_size=8, test_name=""):
        """比较Tile和Normal两种模型"""
        print(f"\n{'='*80}")
        print(f"对比测试: {test_name}")
        print(f"输入尺寸: {input_tensor.shape}")
        print(f"参数配置: hidden_channels={hidden_channels}, z_dim={z_dim}, tile_size={tile_size}")
        print(f"{'='*80}")
        
        results = {}
        
        # 测试Normal VAE Encoder
        try:
            normal_model = NormalVAEEncoder3D(
                in_channels=input_tensor.size(1),
                hidden_channels=hidden_channels,
                z_dim=z_dim
            ).to(self.device)
            
            normal_result = self.profile_single_model(normal_model, input_tensor, "Normal VAE")
            results['normal'] = normal_result
            
            del normal_model
            self.clear_cache()
            
        except Exception as e:
            print(f"❌ Normal VAE 创建失败: {e}")
            results['normal'] = {
                'model_type': 'Normal VAE',
                'success': False,
                'error_msg': str(e),
                'peak_memory': float('inf'),
                'processing_time': float('inf')
            }
        
        # 测试Tile VAE Encoder
        try:
            tile_model = TileVAEEncoder3D(
                in_channels=input_tensor.size(1),
                hidden_channels=hidden_channels,
                z_dim=z_dim,
                tile_size=tile_size
            ).to(self.device)
            
            tile_result = self.profile_single_model(tile_model, input_tensor, f"Tile VAE (tile_size={tile_size})")
            results['tile'] = tile_result
            
            del tile_model
            self.clear_cache()
            
        except Exception as e:
            print(f"❌ Tile VAE 创建失败: {e}")
            results['tile'] = {
                'model_type': f'Tile VAE (tile_size={tile_size})',
                'success': False,
                'error_msg': str(e),
                'peak_memory': float('inf'),
                'processing_time': float('inf')
            }
        
        # 对比分析
        self._analyze_comparison(results, test_name)
        
        self.comparison_results.append({
            'test_name': test_name,
            'input_shape': input_tensor.shape,
            'results': results
        })
        
        return results
    
    def _analyze_comparison(self, results, test_name):
        """分析对比结果"""
        print(f"\n{'='*80}")
        print(f"对比分析: {test_name}")
        print(f"{'='*80}")
        
        if results['normal']['success'] and results['tile']['success']:
            normal = results['normal']
            tile = results['tile']
            
            # 显存对比
            memory_savings = normal['peak_memory'] - tile['peak_memory']
            memory_savings_pct = (memory_savings / normal['peak_memory']) * 100 if normal['peak_memory'] > 0 else 0
            
            # 时间对比
            time_diff = tile['processing_time'] - normal['processing_time']
            time_diff_pct = (time_diff / normal['processing_time']) * 100 if normal['processing_time'] > 0 else 0
            
            print(f"📊 显存使用对比:")
            print(f"  Normal VAE:  {normal['peak_memory']:.3f} GB")
            print(f"  Tile VAE:    {tile['peak_memory']:.3f} GB")
            if memory_savings > 0:
                print(f"  💚 Tile方法节省显存: {memory_savings:.3f} GB ({memory_savings_pct:.1f}%)")
            else:
                print(f"  🔴 Tile方法增加显存: {abs(memory_savings):.3f} GB ({abs(memory_savings_pct):.1f}%)")
            
            print(f"\n⏱️  处理时间对比:")
            print(f"  Normal VAE:  {normal['processing_time']:.3f} 秒")
            print(f"  Tile VAE:    {tile['processing_time']:.3f} 秒")
            if time_diff > 0:
                print(f"  🔴 Tile方法增加时间: {time_diff:.3f} 秒 ({time_diff_pct:.1f}%)")
            else:
                print(f"  💚 Tile方法节省时间: {abs(time_diff):.3f} 秒 ({abs(time_diff_pct):.1f}%)")
            
            print(f"\n🎯 输出对比:")
            print(f"  Normal VAE输出数: {normal['num_outputs']}")
            print(f"  Tile VAE输出数:   {tile['num_outputs']}")
            
            # 效率评估
            if memory_savings > 0 and time_diff < normal['processing_time'] * 0.5:
                print(f"  ✅ 推荐使用Tile方法: 显存节省明显，时间开销可接受")
            elif memory_savings > 0:
                print(f"  ⚠️  Tile方法: 节省显存但时间开销较大，根据需求选择")
            else:
                print(f"  ❌ 不推荐Tile方法: 显存和时间开销都增加")
        
        elif results['normal']['success']:
            print(f"✅ 只有Normal VAE成功执行")
            print(f"❌ Tile VAE执行失败: {results['tile']['error_msg']}")
            print(f"💡 建议: 减小输入尺寸或tile_size重试")
        
        elif results['tile']['success']:
            print(f"❌ Normal VAE执行失败: {results['normal']['error_msg']}")
            print(f"✅ 只有Tile VAE成功执行")
            print(f"💡 这表明Tile方法在处理大尺寸输入时具有优势")
        
        else:
            print(f"❌ 两种方法都执行失败")
            print(f"Normal VAE: {results['normal']['error_msg']}")
            print(f"Tile VAE: {results['tile']['error_msg']}")


def run_comprehensive_comparison():
    """运行全面对比测试"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")
    
    if device.type == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name()}")
        print(f"总显存: {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB")
    
    comparator = MemoryComparator(device)
    
    # 测试配置 - 从小到大逐步测试
    test_configs = [
        {
            'name': '小尺寸测试',
            'input_shape': (1, 3, 16, 64, 128),
            'tile_size': 4,
            'hidden_channels': 32,
            'z_dim': 16
        },
        {
            'name': '中等尺寸测试',
            'input_shape': (1, 3, 32, 128, 256),
            'tile_size': 8,
            'hidden_channels': 64,
            'z_dim': 32
        },
        {
            'name': '大尺寸测试',
            'input_shape': (1, 3, 48, 180, 960),
            'tile_size': 12,
            'hidden_channels': 64,
            'z_dim': 32
        },
        {
            'name': '超大尺寸测试',
            'input_shape': (1, 3, 64, 256, 1024),
            'tile_size': 16,
            'hidden_channels': 64,
            'z_dim': 32
        },
        {
            'name': '批处理测试',
            'input_shape': (2, 3, 24, 128, 256),
            'tile_size': 8,
            'hidden_channels': 64,
            'z_dim': 32
        }
    ]
    
    all_results = []
    
    for config in test_configs:
        try:
            input_tensor = torch.randn(config['input_shape']).to(device)
            
            results = comparator.compare_models(
                input_tensor=input_tensor,
                hidden_channels=config['hidden_channels'],
                z_dim=config['z_dim'],
                tile_size=config['tile_size'],
                test_name=config['name']
            )
            
            all_results.append(results)
            
            del input_tensor
            comparator.clear_cache()
            
        except Exception as e:
            print(f"测试 '{config['name']}' 失败: {e}")
            comparator.clear_cache()
    
    return all_results, comparator.comparison_results


def summarize_results(comparison_results):
    """总结所有测试结果"""
    print(f"\n{'='*100}")
    print("🎯 总体测试结果汇总")
    print(f"{'='*100}")
    
    successful_normal = 0
    successful_tile = 0
    memory_savings_cases = 0
    time_overhead_cases = 0
    
    print(f"{'测试名称':<15} {'Normal状态':<10} {'Tile状态':<10} {'显存节省(GB)':<12} {'时间差异(s)':<12} {'推荐'}")
    print("-" * 100)
    
    for result in comparison_results:
        test_name = result['test_name'][:14]
        normal_status = "✅" if result['results']['normal']['success'] else "❌"
        tile_status = "✅" if result['results']['tile']['success'] else "❌"
        
        if result['results']['normal']['success']:
            successful_normal += 1
        if result['results']['tile']['success']:
            successful_tile += 1
        
        if result['results']['normal']['success'] and result['results']['tile']['success']:
            memory_diff = result['results']['normal']['peak_memory'] - result['results']['tile']['peak_memory']
            time_diff = result['results']['tile']['processing_time'] - result['results']['normal']['processing_time']
            
            if memory_diff > 0:
                memory_savings_cases += 1
            if time_diff > 0:
                time_overhead_cases += 1
            
            memory_str = f"{memory_diff:+.3f}"
            time_str = f"{time_diff:+.3f}"
            
            # 推荐逻辑
            if memory_diff > 0.1 and time_diff < result['results']['normal']['processing_time'] * 0.5:
                recommendation = "Tile ✅"
            elif memory_diff > 0:
                recommendation = "Tile ⚠️"
            else:
                recommendation = "Normal"
        else:
            memory_str = "N/A"
            time_str = "N/A"
            if result['results']['tile']['success'] and not result['results']['normal']['success']:
                recommendation = "Tile ✅"
            else:
                recommendation = "N/A"
        
        print(f"{test_name:<15} {normal_status:<10} {tile_status:<10} {memory_str:<12} {time_str:<12} {recommendation}")
    
    print(f"\n📈 统计信息:")
    print(f"  Normal VAE 成功率: {successful_normal}/{len(comparison_results)} ({successful_normal/len(comparison_results)*100:.1f}%)")
    print(f"  Tile VAE 成功率:   {successful_tile}/{len(comparison_results)} ({successful_tile/len(comparison_results)*100:.1f}%)")
    
    if memory_savings_cases > 0:
        print(f"  显存节省案例: {memory_savings_cases}/{len(comparison_results)} ({memory_savings_cases/len(comparison_results)*100:.1f}%)")
    
    print(f"\n💡 总结建议:")
    if successful_tile > successful_normal:
        print("  🎯 Tile方法在处理大尺寸数据时表现更好，推荐用于显存受限场景")
    elif memory_savings_cases >= len(comparison_results) // 2:
        print("  🎯 Tile方法在多数情况下能节省显存，推荐在显存紧张时使用")
    else:
        print("  🎯 根据具体需求选择：显存充足时用Normal，显存受限时用Tile")


if __name__ == "__main__":
    print("🎯 Tile vs Normal VAE Encoder 显存峰值对比测试")
    print("=" * 60)
    
    # 选择测试模式
    test_mode = input("选择测试模式 (1-快速测试, 2-完整测试, 3-自定义): ").strip()
    
    if test_mode == "1":
        # 快速测试
        print("\n🚀 执行快速显存峰值测试...")
        quick_memory_test()
        
    elif test_mode == "3":
        # 自定义测试
        print("\n🔧 自定义测试参数:")
        try:
            batch = int(input("批大小 (默认1): ") or "1")
            depth = int(input("深度 (默认32): ") or "32") 
            height = int(input("高度 (默认128): ") or "128")
            width = int(input("宽度 (默认256): ") or "256")
            tile_size = int(input("Tile大小 (默认8): ") or "8")
            
            input_shape = (batch, 3, depth, height, width)
            quick_memory_test(input_shape, tile_size)
            
        except ValueError:
            print("❌ 输入参数无效，使用默认参数")
            quick_memory_test()
    
    else:
        # 完整测试 (默认)
        print("\n🎯 执行完整对比测试...")
        results, comparison_results = run_comprehensive_comparison()
        summarize_results(comparison_results)
    
    print(f"\n{'='*60}")
    print("🎉 测试完成！")
    print(f"{'='*60}")